package clientserver;
import java.io.*;
import java.net.*;
import java.util.*;
public class p1a_clientserver {

	public static void main(String[] args)throws IOException {
		client c=new client();
		c.do_echo();
	}
}

class client{
	Socket s;
	DataInputStream din;
	DataOutputStream dout;
	client(){
		try {
			s=new Socket("localhost", 9999);
		}
		catch(Exception e){return;}
	}
	void do_echo() throws IOException{
		//din = new DataInputStream(s.getInputStream());
		dout = new DataOutputStream(s.getOutputStream());
		String st = "abcdef";
		dout.writeUTF(st);
	}
}