package clientserver;
import java.io.*;
import java.net.*;
public class p1a_serverside {

	public static void main(String[] args)throws IOException {
		server sr=new server();
		sr.print();
	}
}

class server {
	ServerSocket ss;
	Socket s;
	DataInputStream din;
	DataOutputStream dout;
	server(){
		try {
			ss=new ServerSocket(9999);
		}
		catch(Exception e){return;}
	}
	void print() throws IOException {
		while(true){
			s=ss.accept();
			din = new DataInputStream(s.getInputStream());
			//dout = new DataOutputStream(s.getOutputStream());
			String st = din.readUTF();
			//dout.writeUTF(st);
			System.out.print(st);
		}
	}
}