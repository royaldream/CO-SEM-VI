import java.sql.*;
import java.util.TimeZone;
public class pl5 {
	public static void main(String[] args) throws ClassNotFoundException {
		try {
			TimeZone time = TimeZone.getTimeZone("yourTimeZone");
			TimeZone.setDefault(time);
			
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@172.16.3.91:1521/orcl","s17cos122","student");
			Statement st = con.createStatement();
			ResultSet rs;
			
			int nor=0;
			rs = st.executeQuery("select * from BOOK");
			ResultSetMetaData rsmd = rs.getMetaData();
			int noc =  rsmd.getColumnCount();
			System.out.println("No.of columns = "+noc);
			
			while(rs.next()) nor++;
			System.out.println("No.of rows = "+nor);
			
			while(noc>0) {
				System.out.println("Datatype of column "+rsmd.getColumnName(noc)+" is "+rsmd.getColumnTypeName(noc));
				noc--;
			}
		}
		catch(SQLException e){System.out.print(e);}
	}
}