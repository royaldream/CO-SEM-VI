﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class dectohex
    {
        public void a()
        {
            Console.WriteLine("Enter a num: ");
            int x, i, n = Convert.ToInt32(Console.ReadLine());
            ArrayList a = new ArrayList();
            while (n > 0)
            {
                x = n % 16;
                //Console.WriteLine(x);
                if (v(x) == ' ') a.Add(x);
                else a.Add(v(x));
                n = (n / 16);
            }
            for (i = a.Count - 1; i >= 0; i--)
            {
                Console.Write(a[i]);
            }
        }
        static char v(int x)
        {
            if (x == 10) return 'A';
            else if (x == 11) return 'B';
            else if (x == 12) return 'C';
            else if (x == 13) return 'D';
            else if (x == 14) return 'E';
            else if (x == 15) return 'F';
            else return ' ';
        }
    }
}
