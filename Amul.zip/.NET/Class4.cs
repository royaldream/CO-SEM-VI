﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class dectooct
    {
        public void a()
        {
            Console.WriteLine("Enter a number: ");
            int i, n = Convert.ToInt32(Console.ReadLine());
            ArrayList a = new ArrayList();
            while (n > 0)
            {
                a.Add(n % 8);
                n = (n / 8);
            }
            for (i = a.Count - 1; i >= 0; i--)
            {
                Console.Write(a[i]);
            }
        }
    }
}
