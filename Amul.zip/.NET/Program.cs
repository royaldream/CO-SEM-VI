﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            bintodec b = new bintodec();
            //b.a();
            //Console.ReadKey();

            dectohex d = new dectohex();
            //d.a();
            //Console.ReadKey();

            dectobin db = new dectobin();
            //db.a();
            //Console.ReadKey();

            dectooct doc = new dectooct();
            doc.a();
            Console.ReadKey();
        }
    }
}

