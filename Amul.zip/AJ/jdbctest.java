import java.sql.*;
/*public class jdbctest {
	public static void main(String[] args) throws ClassNotFoundException{
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mysql","root","");
			Statement st = con.createStatement();
			ResultSet rs;
			
			rs=st.executeQuery("select * from student");
			rs.afterLast();		//to take the cursor to last result
			
			/*while(rs.previous()){
				System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3));
			}*/
			
			//st.execute("insert into student values('amul5',2,'co')");
			
			//rs=st.executeQuery("select * from student");
			//while(rs.next()) System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3));
			
			/*st.execute("delete from student where name='amul5'");
			rs=st.executeQuery("select * from student");
			while(rs.next()) System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3));
		}
		catch(SQLException sq){System.out.print(sq);}
	}
}*/