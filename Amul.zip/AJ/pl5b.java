import java.sql.*;
import java.util.TimeZone;
public class pl5b {
	public static void main(String[] args) throws ClassNotFoundException {
		try {
			TimeZone time = TimeZone.getTimeZone("yourTimeZone");
			TimeZone.setDefault(time);
			
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@172.16.3.91:1521/orcl","s17cos122","student");
			Statement st = con.createStatement();
			ResultSet rs;
			
			CallableStatement cst = con.prepareCall("{call PROCEDURE1(?, ?)}");
			cst.setInt(1, 2);			//cst.setInt(parameter_number_in_call_statement, value_to_be_passed)
			cst.registerOutParameter(2, Types.VARCHAR);		//cst.rOP(parameter_number_in_call_statement, output_type)
			cst.execute();
			System.out.println(cst.getString(2));
		}
		catch(SQLException e){System.out.print(e);}
	}
}