﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Calc
{
    public partial class Form1 : Form
    {
        String x;
        public Form1()
        {
            InitializeComponent();
            //box.Text = "";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            box.Text = box.Text + button10.Text;
            x = button10.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            box.Text = box.Text + button1.Text;
            x = button1.Text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            box.Text = box.Text + button2.Text;
            x = button2.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            box.Text = box.Text + button3.Text;
            x = button3.Text;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            box.Text = box.Text + button4.Text;
            x = button4.Text;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            box.Text = box.Text + button5.Text;
            x = button5.Text;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            box.Text = box.Text + button6.Text;
            x = button6.Text;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            box.Text = box.Text + button7.Text;
            x = button7.Text;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            box.Text = box.Text + button8.Text;
            x = button8.Text;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            box.Text = box.Text + button9.Text;
            x = button9.Text;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            box.Text = box.Text + button17.Text;
            x = ".";
        }

        private void box_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button11_Click(object sender, EventArgs e)
        {
            box.Text = box.Text + button11.Text; 
        }

        private void button12_Click(object sender, EventArgs e)
        {
            box.Text = box.Text + button12.Text;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            box.Text = box.Text + button13.Text;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            box.Text = box.Text + button14.Text;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            box.Text = "";
            textBox1.Text = "";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //textBox1.Text = box.Text;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            //textBox1.Text = box.Text;
            String s=box.Text;
            int x, y,z;
            if (s.Contains("+"))
            {
                x = Convert.ToInt32(s.Substring(0, s.IndexOf("+")));
                y = Convert.ToInt32(s.Substring(s.IndexOf("+") + 1));
                //textBox1.Text = Convert.ToString(x);
                z = Convert.ToInt32(x + y);
                textBox1.Text = Convert.ToString(z);
                box.Text = Convert.ToString(z);
            }
            if (s.Contains("-"))
            {
                x = Convert.ToInt32(s.Substring(0, s.IndexOf("-")));
                y = Convert.ToInt32(s.Substring(s.IndexOf("-") + 1));
                //textBox1.Text = Convert.ToString(x);
                z = Convert.ToInt32(x - y);
                textBox1.Text = Convert.ToString(z);
                box.Text = Convert.ToString(z);
            }
            if (s.Contains("*"))
            {
                x = Convert.ToInt32(s.Substring(0, s.IndexOf("*")));
                y = Convert.ToInt32(s.Substring(s.IndexOf("*") + 1));
                //textBox1.Text = Convert.ToString(x);
                z = Convert.ToInt32(x * y);
                textBox1.Text = Convert.ToString(z);
                box.Text = Convert.ToString(z);
            }
            if (s.Contains("/"))
            {
                x = Convert.ToInt32(s.Substring(0, s.IndexOf("/")));
                y = Convert.ToInt32(s.Substring(s.IndexOf("/") + 1));
                //textBox1.Text = Convert.ToString(x);
                z = Convert.ToInt32(x / y);
                textBox1.Text = Convert.ToString(z);
                box.Text = Convert.ToString(z);
            }
        }
    }
}
