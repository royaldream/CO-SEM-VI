﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace ConsoleApplication1
{
    public class bintodec
    {
        public void a()
        {
            Console.WriteLine("Enter a number: ");
            int s=0, i;
            String n = (Console.ReadLine());
            //ArrayList a = new ArrayList();
            //int[] a = new int[n.Length];
            int nn = Convert.ToInt32(n);
            
            for(i=0;i<n.Length;i++)
            {
                
                s = s + ((nn%10) * Convert.ToInt32(Math.Pow(2, i)));
                nn = nn / 10;
            }
            Console.Write(s);
        }
    }
}
