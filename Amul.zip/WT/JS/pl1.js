document.write("This is external JavaScript");
