import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.*;

import javax.swing.*;

import java.sql.*;

//creating GUI using Swing
class test extends JFrame implements ActionListener{
	JButton ins,upd,del;
	JTextField tf;
	JPanel jp;
	JLabel l1,l2;

	test(){
		setSize(200,200);			//component class of java.awt
		setTitle("SQL Operations");     //frame class of java.awt

		Container c=this.getContentPane();
		
		ins = new JButton("Insert");
		upd = new JButton("Update");
		del = new JButton("Delete");
		
		jp = new JPanel();
		jp.add(ins);
		jp.add(upd);
		jp.add(del);
		
		c.add(jp);
		
		ins.addActionListener(this);
		upd.addActionListener(this);
		del.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mysql","root","");
			Statement st = con.createStatement();
			ResultSet rs;
			
			l1 = new JLabel("Enter your Query: ");
			tf = new JTextField();
			jp.add(l1);
			jp.add(tf);
			c.add(jp);
			
			if(e.getSource()==ins){
				String q=tf.getText();
				st.execute(q);
			}
			if(e.getSource()==upd){
				String q=tf.getText();
				st.execute(q);
			}
			if(e.getSource()==del){
				String q=tf.getText();
				st.execute(q);
			}
		}
		catch(SQLException sq){System.out.print(sq);} 
		catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}
public class pl4B {
	public static void main(String[] args) throws ClassNotFoundException{
		test ts=new test();
		ts.setVisible(true); 
	}
}
